/**
 * Strategy Configuration - FIXED PARAMETERS (v1)
 * 
 * These are NOT user-editable in MVP v1.
 * Any customization is post-MVP.
 */

export const STRATEGY = {
  // ═══════════════════════════════════════════════════════════════
  // TREND FILTER (Higher Timeframe)
  // ═══════════════════════════════════════════════════════════════
  trend: {
    ema: {
      period: 200,           // EMA period for trend direction
      slopeLookback: 3,      // Bars to calculate slope
    },
    adx: {
      period: 14,            // ADX period
      threshold: 20,         // Minimum ADX for valid trend
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // ENTRY TRIGGER (Lower Timeframe)
  // ═══════════════════════════════════════════════════════════════
  entry: {
    emaFast: {
      period: 20,            // Fast EMA for shallow pullback
    },
    emaSlow: {
      period: 50,            // Slow EMA for deep pullback
    },
    rsi: {
      period: 14,
      bullishResetBelow: 50, // RSI must go below this for bullish reset
      bearishResetAbove: 50, // RSI must go above this for bearish reset
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // STOP LOSS
  // ═══════════════════════════════════════════════════════════════
  stopLoss: {
    swingLookback: 10,       // Bars to find swing high/low
    atr: {
      period: 14,
      multiplier: 1.5,       // ATR multiplier for fallback SL
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // TAKE PROFIT
  // ═══════════════════════════════════════════════════════════════
  takeProfit: {
    minRR: 2.0,              // Minimum risk:reward ratio
  },

  // ═══════════════════════════════════════════════════════════════
  // GRADING THRESHOLDS
  // ═══════════════════════════════════════════════════════════════
  grading: {
    // A+ requires all conditions perfectly met
    // B allows slightly weaker RSI or borderline ADX
    adxBorderline: {
      min: 18,               // ADX 18-20 = borderline (B grade)
      ideal: 20,             // ADX 20+ = strong (A+ eligible)
    },
    rsiResetStrength: {
      strong: 5,             // RSI moved 5+ points from reset level
      weak: 2,               // RSI moved 2-5 points (B grade)
    },
  },
} as const;

// ═══════════════════════════════════════════════════════════════
// TRADING STYLE PRESETS
// ═══════════════════════════════════════════════════════════════

export type TradingStyle = 'intraday' | 'swing';

export interface StyleConfig {
  name: string;
  trendTimeframe: string;      // Higher timeframe for trend
  entryTimeframe: string;      // Lower timeframe for entry
  refreshMinutes: number;      // How often to refresh
  validCandles: number;        // How many candles signal is valid
  avInterval: string;          // Alpha Vantage interval param
  avTrendInterval: string;     // Alpha Vantage interval for trend TF
}

export const STYLE_PRESETS: Record<TradingStyle, StyleConfig> = {
  intraday: {
    name: 'Intraday',
    trendTimeframe: 'H4',
    entryTimeframe: 'H1',
    refreshMinutes: 5,
    validCandles: 4,           // ~4 hours
    avInterval: '60min',
    avTrendInterval: '60min',  // We'll use daily for H4 approximation
  },
  swing: {
    name: 'Swing',
    trendTimeframe: 'D1',
    entryTimeframe: 'H4',
    refreshMinutes: 15,
    validCandles: 6,           // ~24 hours
    avInterval: '60min',       // We'll aggregate to H4
    avTrendInterval: 'daily',
  },
};

export function getStyleConfig(style: TradingStyle): StyleConfig {
  return STYLE_PRESETS[style];
}
